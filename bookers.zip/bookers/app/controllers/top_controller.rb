class TopController < ActionController::Base
  def index
  end
end